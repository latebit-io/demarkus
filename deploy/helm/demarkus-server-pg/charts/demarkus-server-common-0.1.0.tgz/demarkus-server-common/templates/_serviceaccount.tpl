{{- define "demarkus-server.serviceaccount" -}}
{{- if .Values.serviceAccount.create }}
apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ include "demarkus-server.serviceAccountName" . }}
  labels:
    {{- include "demarkus-server.labels" . | nindent 4 }}
  {{- $extraAnnotations := .Values.serviceAccount.annotations | default dict }}
  {{- if .Values.serviceAccount.workloadIdentity.gsa }}
  {{- $extraAnnotations = mergeOverwrite $extraAnnotations (dict "iam.gke.io/gcp-service-account" .Values.serviceAccount.workloadIdentity.gsa) }}
  {{- end }}
  {{- if $extraAnnotations }}
  annotations:
    {{- toYaml $extraAnnotations | nindent 4 }}
  {{- end }}
{{- end }}
{{- end -}}
